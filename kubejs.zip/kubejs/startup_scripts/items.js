StartupEvents.registry("item", event => {
    event.create("integrated_mechanism")
    event.create("integrated_circuit")
    event.create("kinetic_mechanism")
    event.create("sealed_mechanism")
    event.create("calculation_mechanism")
    //event.create("boiling_mechanism")
    event.create("capacitor_mechanism")
    event.create("incomplete_integrated_mechanism", "create:sequenced_assembly")
    event.create("incomplete_integrated_circuit", "create:sequenced_assembly")
    event.create("incomplete_kinetic_mechanism", "create:sequenced_assembly")
    event.create("incomplete_sealed_mechanism", "create:sequenced_assembly")
    event.create("incomplete_calculation_mechanism", "create:sequenced_assembly")
    //event.create("incomplete_boiling_mechanism", "create:sequenced_assembly")
    event.create("incomplete_capacitor_mechanism", "create:sequenced_assembly")
    event.create("rubber")
    event.create("raw_rubber")
    event.create("goo")

    event.create("kubejs:build_up_copper_golem")
})

StartupEvents.registry("block", event => {
    event.create("copper_golem")
        .notSolid()
        .fullBlock(false)

    event.create("lit_up_rose_quartz_lamp")
        .lightLevel(1)
        .glassSoundType()
})

StartupEvents.registry("fluid", event => {
    event.create("liquid_rose_quartz")
        .thickTexture(0xF74572)
        .bucketColor(0xF74572)
        
})

BlockEvents.modification(event => {
    event.modify("kubejs:liquid_rose_quartz", block => {
        block.setLightEmission(15)
    })
})