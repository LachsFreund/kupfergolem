ServerEvents.recipes(event => {
  event.custom({
    type: "create:sequenced_assembly",
    ingredient: { item: "minecraft:gold_ingot" },
    loops: 1,
    results: [
      { item: "kubejs:capacitor_mechanism" },
    ],
    sequence: [
      {
        type: "create:pressing",
        ingredients: [
          { item: "minecraft:gold_ingot" },
        ],
        results: [
          { item: "kubejs:incomplete_capacitor_mechanism" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:incomplete_capacitor_mechanism" },
          { item: "create:zinc_ingot" }
        ],
        results: [
          { item: "kubejs:incomplete_capacitor_mechanism" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:incomplete_capacitor_mechanism" },
          { item: "minecraft:copper_ingot" }
        ],
        results: [
          { item: "kubejs:capacitor_mechanism" }
        ]
      },
    ],
    transitionalItem: { item: "kubejs:incomplete_capacitor_mechanism" }
  });
});
