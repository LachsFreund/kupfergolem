ServerEvents.recipes(event => {
    event.custom({
        type: "create:deploying",
        ingredients: [
        { item: "minecraft:pumpkin" },
        { item: "minecraft:shears" },
       ],
        keepHeldItem: true,
        results: [
        { item: "minecraft:carved_pumpkin", count: 1 },
        ]

    })
})