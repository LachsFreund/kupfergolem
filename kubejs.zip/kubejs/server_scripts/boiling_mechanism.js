ServerEvents.recipes(event => {
  event.custom({
    type: "create:sequenced_assembly",
    ingredient: { item: "minecraft:copper_ingot" },
    loops: 1,
    results: [
      { item: "kubejs:boiling_mechanism" },
    ],
    sequence: [
      {
        type: "create:pressing",
        ingredients: [
          { item: "minecraft:copper_ingot" },
        ],
        results: [
          { item: "kubejs:incomplete_boiling_mechanism" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:incomplete_boiling_mechanism" },
          { item: "create:andesite_alloy" }
        ],
        results: [
          { item: "kubejs:incomplete_boiling_mechanism" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:incomplete_boiling_mechanism" },
          { item: "create:iron_sheet" }
        ],
        results: [
          { item: "kubejs:boiling_mechanism" }
        ]
      },
    ],
    transitionalItem: { item: "kubejs:incomplete_boiling_mechanism" }
  });
});
