ServerEvents.recipes(event => {
  event.custom({
    type: "create:sequenced_assembly",
    ingredient: { item: "create:brass_sheet" },
    loops: 1,
    results: [
      { item: "kubejs:integrated_mechanism" },
    ],
    sequence: [
      {
        type: "create:deploying",
        ingredients: [
          { item: "create:brass_sheet" },
          { item: "create:electron_tube" }
        ],
        results: [
          { item: "kubejs:incomplete_integrated_mechanism" }
        ]
      },
      {
        type: "create:pressing",
        ingredients: [
          { item: "kubejs:incomplete_integrated_mechanism" },
        ],
        results: [
          { item: "kubejs:incomplete_integrated_mechanism" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:incomplete_integrated_mechanism" },
          { item: "kubejs:integrated_circuit" }
        ],
        results: [
          { item: "kubejs:incomplete_integrated_mechanism" }
        ]
      },
      {
        type: "create:pressing",
        ingredients: [
          { item: "kubejs:incomplete_integrated_mechanism" },
        ],
        results: [
          { item: "kubejs:integrated_mechanism" }
        ]
      },
    ],
    transitionalItem: { item: "kubejs:incomplete_integrated_mechanism" }
  });
});
