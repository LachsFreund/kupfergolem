ServerEvents.recipes(event => {
  event.custom({
    type: "create:sequenced_assembly",
    ingredient: { item: "create:brass_sheet" },
    loops: 1,
    results: [
      { item: "kubejs:integrated_circuit" },
    ],
    sequence: [
      {
        type: "create:deploying",
        ingredients: [
          { item: "create:brass_sheet" },
          { item: "minecraft:lapis_block" }
        ],
        results: [
          { item: "kubejs:incomplete_integrated_circuit" }
        ]
      },
      {
        type: "create:pressing",
        ingredients: [
          { item: "kubejs:incomplete_integrated_circuit" },
        ],
        results: [
          { item: "kubejs:integrated_circuit" }
        ]
      },
    ],
    transitionalItem: { item: "kubejs:incomplete_integrated_circuit" }
  });
});
