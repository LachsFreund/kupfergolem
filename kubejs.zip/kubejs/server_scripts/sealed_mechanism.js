ServerEvents.recipes(event => {
  event.custom({
    type: "create:sequenced_assembly",
    ingredient: { item: "create:weathered_iron_block" },
    loops: 1,
    results: [
      { item: "kubejs:sealed_mechanism" },
    ],
    sequence: [
      {
        type: "create:deploying",
        ingredients: [
          { item: "create:weathered_iron_block" },
          { item: "create:fluid_tank" }
        ],
        results: [
          { item: "kubejs:incomplete_sealed_mechanism" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:incomplete_sealed_mechanism" },
          { item: "create:mechanical_pump" }
        ],
        results: [
          { item: "kubejs:incomplete_sealed_mechanism" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:incomplete_sealed_mechanism" },
          { item: "minecraft:copper_ingot" }
        ],
        results: [
          { item: "kubejs:sealed_mechanism" }
        ]
      },
    ],
    transitionalItem: { item: "kubejs:incomplete_sealed_mechanism" }
  });
});
