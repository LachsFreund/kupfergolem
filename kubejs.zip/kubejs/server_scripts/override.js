ServerEvents.recipes(event => {

  event.remove({ output: 'create:polished_rose_quartz', type: 'create:sandpaper_polishing' })

})

ServerEvents.recipes(event => {
    event.custom({
        type: "create:deploying",
        ingredients: [
        { item: "create:rose_quartz" },
        { tag: "create:sandpaper"}
       ],
        keepHeldItem: true,
        results: [
        { item: "create:polished_rose_quartz", count: 1 },
        ]
    })
})