ServerEvents.tick(event => {
  const players = event.server.players;

  players.forEach(player => {
    const block = player.level.getBlock(player.blockX, player.blockY, player.blockZ);

    if (block.id === 'kubejs:liquid_rose_quartz') {
      player.potionEffects.add('minecraft:instant_damage', 3, 0.1, false, false);
    }
  })
})