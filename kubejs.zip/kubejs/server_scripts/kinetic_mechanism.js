ServerEvents.recipes(event => {
  event.custom({
    type: "create:sequenced_assembly",
    ingredient: { item: "create:andesite_alloy" },
    loops: 1,
    results: [
      { item: "kubejs:kinetic_mechanism" },
    ],
    sequence: [
        {
        type: "create:pressing",
        ingredients: [
          { item: "create:andesite_alloy" },
        ],
        results: [
          { item: "kubejs:incomplete_kinetic_mechanism" }
        ]
        },
        {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:incomplete_kinetic_mechanism" },
          { item: "create:cogwheel" }
        ],
        results: [
          { item: "kubejs:incomplete_kinetic_mechanism" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:incomplete_kinetic_mechanism" },
          { item: "create:large_cogwheel" }
        ],
        results: [
          { item: "kubejs:incomplete_kinetic_mechanism" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:incomplete_kinetic_mechanism" },
          { item: "create:zinc_nugget" }
        ],
        results: [
          { item: "kubejs:kinetic_mechanism" }
        ]
      },
    ],
    transitionalItem: { item: "kubejs:incomplete_kinetic_mechanism" }
  });
});
