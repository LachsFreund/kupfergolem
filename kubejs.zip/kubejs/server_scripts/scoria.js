ServerEvents.recipes(event => {
  event.custom({
    type: "create:crushing",
    ingredients: [
      { item: "create:scoria" }
    ], 
    processingTime: 200,
    results: [
      { item: 'minecraft:stick', chance: 0.7 },
      { item: 'create:rose_quartz', chance: 0.5 },
      { item: 'minecraft:copper_ingot', chance: 0.5 },
      { item: 'create:andesite_alloy', chance: 0.5 },
      { item: 'minecraft:cobblestone', chance: 0.4 },
      { item: 'minecraft:slime_ball', chance: 0.5 },
      { item: 'minecraft:lapis_lazuli', chance: 0.5 },
      { item: 'minecraft:iron_ingot', chance: 0.5 },
      { item: 'create:zinc_ingot', chance: 0.5 },
      { item: 'create:brass_ingot', chance: 0.5 },
      { item: 'create:limestone', chance: 0.5 },
      { item: 'minecraft:dead_bush', chance: 0.3 },

    ]
  })
})