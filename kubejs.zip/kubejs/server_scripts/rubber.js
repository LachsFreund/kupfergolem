ServerEvents.recipes(event => {
    event.custom({
        type: "create:pressing",
        ingredients: [
        { item: "minecraft:slime_ball" },
        ],
        results: [
        { item: "kubejs:goo", count: 1 },
        ]

    })

    event.custom({
        type: "create:mixing",
        ingredients: [
        { item: "kubejs:goo" },
        ],
        results: [
        { item: "kubejs:raw_rubber", count: 1 },
        ]

    })

    event.custom({
        type: "minecraft:smoking",
        category:"misc",
        cookingtime:200,
        experience:1,
        ingredient: [
        { item: "kubejs:raw_rubber" },
        ],
        result: "kubejs:rubber"
        

    })
})