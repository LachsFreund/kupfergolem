ServerEvents.recipes(event => {
  event.custom({
    type: "create:sequenced_assembly",
    ingredient: { item: "create:andesite_alloy" },
    loops: 1,
    results: [
      { item: "kubejs:calculation_mechanism" },
    ],
    sequence: [
        {
        type: "create:pressing",
        ingredients: [
          { item: "create:andesite_alloy" },
        ],
        results: [
          { item: "kubejs:incomplete_calculation_mechanism" }
        ]
        },
        {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:incomplete_calculation_mechanism" },
          { item: "create:cogwheel" }
        ],
        results: [
          { item: "kubejs:incomplete_calculation_mechanism" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:incomplete_calculation_mechanism" },
          { item: "create:copper_nugget" }
        ],
        results: [
          { item: "kubejs:calculation_mechanism" }
        ]
      },
    ],
    transitionalItem: { item: "kubejs:incomplete_calculation_mechanism" }
  });
});
