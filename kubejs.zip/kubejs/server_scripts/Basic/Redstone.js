ServerEvents.recipes(event => {
    event.custom({
        type: "create:mixing",
        ingredients: [
        { item: "minecraft:flint" },
        { item: "minecraft:netherrack" },
        { fluid: "minecraft:lava", amount: 250 }
        ],
        results: [
        { item: "minecraft:redstone", count: 1 },
        ]

    })
})