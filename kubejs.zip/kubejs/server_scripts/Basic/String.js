ServerEvents.recipes(event => {
    event.custom({
        type: "create:pressing",
        ingredients: [
        { tag: "minecraft:leaves" },
       ],
        results: [
        { item: "minecraft:string", count: 1 },
        ]

    })
})