ServerEvents.recipes(event => {
    event.custom({
        type: "create:compacting",
        heatRequirement: "heated",
        ingredients: [
        { item: "minecraft:cobblestone" }
        ],
        results: [
        { fluid: "minecraft:lava", amount: 50 },
        ]

    })
})