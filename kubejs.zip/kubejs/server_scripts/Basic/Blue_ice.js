ServerEvents.recipes(event => {
    event.custom({
        type: "create:splashing",
        ingredients: [
            { item: "minecraft:snowball"},
        ],
        results: [
        { item: "minecraft:ice" },
        ]

    })

    event.custom({
        type: "create:splashing",
        ingredients: [
            { item: "minecraft:ice"},
        ],
        results: [
        { item: "minecraft:packed_ice" },
        ]

    })

    event.custom({
        type: "create:splashing",
        ingredients: [
            { item: "minecraft:packed_ice"},
        ],
        results: [
        { item: "minecraft:blue_ice" },
        ]

    })
})