ServerEvents.recipes(event => {
event.custom({
        type: "create:milling",
        ingredients: [
        { item: "create:limestone" }
        ],
        "processing_time": 250,
        results: [
        { item: "minecraft:flint" },
        { item: "create:copper_nugget", chance: 0.20 },
        { item: "minecraft:quartz", chance: 0.25 }
        ]

    })
})