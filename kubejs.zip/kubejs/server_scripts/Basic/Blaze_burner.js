ServerEvents.recipes(event => {
    event.custom({
        type: "create:filling",
        ingredients: [
        { item: "create:empty_blaze_burner" },
        { fluid: "minecraft:lava", amount: 1000 }
        ],
        results: [
        { item: "create:blaze_burner", count: 1 },
        ]

    })
})