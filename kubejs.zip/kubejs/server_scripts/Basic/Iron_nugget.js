ServerEvents.recipes(event => {
    
    event.remove({ output: 'minecraft:flint', type: 'create:splashing' })
    
    event.custom({
        type: "create:splashing",
        ingredients: [
            { item: "minecraft:gravel"},
        ],
        results: [
        { item: "minecraft:flint", chance: 0.35 },
        { item: "minecraft:iron_nugget", chance: 0.25 },
        ]

    })
})