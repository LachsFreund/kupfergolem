ServerEvents.recipes(event => {
    event.custom({
        type: "create:pressing",
        ingredients: [
        { "tag": "create:pulpifiable" },
       ],
        results: [
        { item: "minecraft:paper", count: 1 },
        ]

    })
})