ServerEvents.recipes(event => {
event.custom({
        type: "create:crushing",
        ingredients: [
        { item: "minecraft:quartz" }
        ],
        "processing_time": 250,
        results: [
        { item: "create:experience_nugget" },
        { item: "create:experience_nugget", chance: 0.20 },
        ]

    })
})