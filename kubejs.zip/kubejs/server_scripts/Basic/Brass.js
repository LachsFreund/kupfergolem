ServerEvents.recipes(event => {
    event.custom({
        type: "create:mixing",
        heatRequirement: "heated",
        ingredients: [
        { item: "minecraft:copper_ingot" },
        { item: "create:andesite_alloy" }
        ],
        results: [
        { item: "create:brass_ingot", count: 2 },
        ]

    })

    event.custom({
        type: "create:mixing",
        heatRequirement: "heated",
        ingredients: [
        { item: "minecraft:copper_ingot" },
        { item: "minecraft:iron_ingot" }
        ],
        results: [
        { item: "create:brass_ingot", count: 2 },
        ]

    })
})