ServerEvents.recipes(event => {
  event.custom({
    type: "create:sequenced_assembly",
    ingredient: { item: "minecraft:copper_block" },
    loops: 1,
    results: [
      { item: "kubejs:copper_golem" },
    ],
    sequence: [
      {
        type: "create:deploying",
        ingredients: [
          { item: "minecraft:copper_block" },
          { item: "create:copper_casing" }
        ],
        results: [
          { item: "kubejs:build_up_copper_golem" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:build_up_copper_golem" },
          { item: "kubejs:integrated_mechanism" }
        ],
        results: [
          { item: "kubejs:build_up_copper_golem" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:build_up_copper_golem" },
          { item: "kubejs:integrated_circuit" }
        ],
        results: [
          { item: "kubejs:build_up_copper_golem" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:build_up_copper_golem" },
          { item: "kubejs:kinetic_mechanism" }
        ],
        results: [
          { item: "kubejs:build_up_copper_golem" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:build_up_copper_golem" },
          { item: "kubejs:sealed_mechanism" }
        ],
        results: [
          { item: "kubejs:build_up_copper_golem" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:build_up_copper_golem" },
          { item: "kubejs:calculation_mechanism" }
        ],
        results: [
          { item: "kubejs:build_up_copper_golem" }
        ]
      },
      //{
      //  type: "create:deploying",
      //  ingredients: [
      //    { item: "kubejs:build_up_copper_golem" },
      //    { item: "kubejs:boiling_mechanism" }
      //  ],
      //  results: [
      //    { item: "kubejs:build_up_copper_golem" }
      //  ]
      //},
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:build_up_copper_golem" },
          { item: "kubejs:capacitor_mechanism" }
        ],
        results: [
          { item: "kubejs:build_up_copper_golem" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:build_up_copper_golem" },
          { item: "minecraft:carved_pumpkin" }
        ],
        results: [
          { item: "kubejs:build_up_copper_golem" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:build_up_copper_golem" },
          { item: "kubejs:lit_up_rose_quartz_lamp" }
        ],
        results: [
          { item: "kubejs:build_up_copper_golem" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:build_up_copper_golem" },
          { item: "minecraft:lightning_rod" }
        ],
        results: [
          { item: "kubejs:build_up_copper_golem" }
        ]
      },
      {
        type: "create:deploying",
        ingredients: [
          { item: "kubejs:build_up_copper_golem" },
          { item: "create:experience_nugget" }
        ],
        results: [
          { item: "kubejs:copper_golem" }
        ]
      },
    ],
    transitionalItem: { item: "kubejs:build_up_copper_golem" }
  });
});
