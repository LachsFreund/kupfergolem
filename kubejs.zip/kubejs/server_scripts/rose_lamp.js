ServerEvents.recipes(event => {
    event.custom({
        type: "create:filling",
        ingredients: [
        { item: "create:rose_quartz_lamp" },
        { fluid: "kubejs:liquid_rose_quartz", amount: 500 }
        ],
        results: [
        { item: "kubejs:lit_up_rose_quartz_lamp", count: 1 },
        ]

    })
})

ServerEvents.recipes(event => {
    event.custom({
        type: "create:mixing",
        heatRequirement: "heated",
        ingredients: [
        { item: "create:polished_rose_quartz", count: 1 },
        ],
        results: [
        { fluid: "kubejs:liquid_rose_quartz", amount: 250 },
        ]

    })
})